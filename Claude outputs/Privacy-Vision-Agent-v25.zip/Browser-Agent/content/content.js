/**
 * content/content.js
 * Entry point injected into the page. Exposes window.__BA API.
 */
(function (window) {
  if (window.__BA_state) return;

  window.__BA_state = {
    registry: new Map(),
    lastResult: null,
    observer: null,
    debounceTimer: null,
    guideCleanup: null,
    userInteractions: []
  };

  // ── Lightweight User Interaction Tracker (Metadata Only) ──────────────────
  const MAX_INTERACTIONS = 20;

  function findElementIdForDomNode(node) {
    if (!node || !window.__BA_state.registry) return null;
    for (const [id, el] of window.__BA_state.registry.entries()) {
      if (el === node || (el && typeof el.contains === 'function' && el.contains(node))) {
        return id;
      }
    }
    return null;
  }

  function recordInteraction(record) {
    if (!Array.isArray(window.__BA_state.userInteractions)) {
      window.__BA_state.userInteractions = [];
    }
    window.__BA_state.userInteractions.push({
      ...record,
      timestamp: Date.now()
    });
    if (window.__BA_state.userInteractions.length > MAX_INTERACTIONS) {
      window.__BA_state.userInteractions.shift();
    }
  }

  // Click tracking (captures target metadata, never typed values)
  document.addEventListener('click', (e) => {
    if (e.target && e.target.closest && e.target.closest('#pv-guide-card')) return;
    const target = e.target;
    if (!target) return;
    const elementId = findElementIdForDomNode(target);
    const tag = (target.tagName || '').toLowerCase();
    const label = (target.getAttribute('aria-label') || target.innerText || target.getAttribute('placeholder') || '').slice(0, 40).trim();

    recordInteraction({
      actor: 'user',
      action: 'click',
      elementId: elementId != null ? String(elementId) : null,
      tag,
      label: label || undefined
    });
  }, { passive: true, capture: true });

  // Field change tracking (METADATA ONLY — NEVER STORES TYPED VALUE)
  document.addEventListener('change', (e) => {
    const target = e.target;
    if (!target) return;
    const tag = (target.tagName || '').toLowerCase();
    if (tag !== 'input' && tag !== 'textarea' && tag !== 'select') return;

    const elementId = findElementIdForDomNode(target);
    const label = (target.getAttribute('aria-label') || target.getAttribute('placeholder') || target.name || '').slice(0, 40).trim();

    recordInteraction({
      actor: 'user',
      action: 'field_change',
      elementId: elementId != null ? String(elementId) : null,
      tag,
      label: label || undefined
    });
  }, { passive: true, capture: true });

  // Scroll tracking (throttled)
  let lastScrollTime = 0;
  let lastScrollY = typeof window !== 'undefined' ? window.scrollY : 0;
  window.addEventListener('scroll', () => {
    const now = Date.now();
    if (now - lastScrollTime > 600) {
      const currentY = window.scrollY;
      const direction = currentY >= lastScrollY ? 'down' : 'up';
      lastScrollY = currentY;
      lastScrollTime = now;

      recordInteraction({
        actor: 'user',
        action: 'scroll',
        direction
      });
    }
  }, { passive: true });

  // Navigation tracking
  window.addEventListener('popstate', () => {
    recordInteraction({
      actor: 'user',
      action: 'navigation',
      to: location.pathname
    });
  });

  window.addEventListener('hashchange', () => {
    recordInteraction({
      actor: 'user',
      action: 'navigation',
      to: location.pathname + location.hash
    });
  });

  function resolveElement(id, targetSelector) {
    const target = id ?? targetSelector;
    if (!target && target !== 0) return null;

    // 1. Direct query via targetSelector if provided
    if (typeof targetSelector === 'string' && targetSelector.trim()) {
      try {
        const direct = document.querySelector(targetSelector);
        if (direct && document.contains(direct)) return direct;
      } catch (_) {}
    }

    // 2. Direct DOM check if id is a selector string
    if (typeof id === 'string') {
      try {
        const direct = document.querySelector(id);
        if (direct && document.contains(direct)) return direct;
      } catch (_) {}
    }

    // 3. Registry cache check
    if (id != null && window.__BA_state?.registry) {
      const cached = window.__BA_state.registry.get(id);
      if (cached && document.contains(cached)) return cached;
    }

    // 4. Last extraction metadata lookup
    const meta = window.__BA_state?.lastResult?.elements?.find((e) =>
      e.id === id || e.selector === targetSelector || e.selector === id
    );
    if (meta && meta.selector && window.__BA_Selectors) {
      const resolved = window.__BA_Selectors.resolveSelector(meta.selector);
      if (resolved && document.contains(resolved)) return resolved;
    }

    // 5. Global selector resolver fallback
    if (typeof targetSelector === 'string' && window.__BA_Selectors) {
      try {
        const resolved = window.__BA_Selectors.resolveSelector(targetSelector);
        if (resolved && document.contains(resolved)) return resolved;
      } catch (_) {}
    }
    if (typeof id === 'string' && window.__BA_Selectors) {
      try {
        const resolved = window.__BA_Selectors.resolveSelector(id);
        if (resolved && document.contains(resolved)) return resolved;
      } catch (_) {}
    }

    return null;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
  }

  function dispatchNativeInput(el, text) {
    const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) {
      setter.call(el, text);
    } else {
      el.value = text;
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // ── Inject all guide CSS once ──────────────────────────────────────────────
  function ensureGuideStyles() {
    if (document.getElementById('pv-guide-styles')) return;
    const s = document.createElement('style');
    s.id = 'pv-guide-styles';
    s.textContent = `
      /* Pulsing ring around the target input */
      @keyframes pvRingPulse {
        0%   { box-shadow: 0 0 0 0   rgba(0,85,184,.55), 0 0 0 0   rgba(0,85,184,.25); }
        60%  { box-shadow: 0 0 0 6px rgba(0,85,184,.25), 0 0 0 14px rgba(0,85,184,0);  }
        100% { box-shadow: 0 0 0 0   rgba(0,85,184,.55), 0 0 0 0   rgba(0,85,184,.25); }
      }
      .pv-field-active {
        outline: 2.5px solid #0055b8 !important;
        outline-offset: 2px !important;
        animation: pvRingPulse 1.8s ease-in-out infinite !important;
        transition: outline .15s ease !important;
        position: relative !important;
        z-index: 100 !important;
      }

      /* Callout card */
      #pv-guide-card {
        position: absolute;
        z-index: 2147483640;
        width: 300px;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 12px 40px rgba(0,0,0,.18), 0 2px 8px rgba(0,0,0,.10);
        border: 1.5px solid #dce7fb;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        overflow: visible;
        pointer-events: auto;
        transform-origin: top left;
      }
      #pv-guide-card.pv-card-enter {
        animation: pvCardIn .35s cubic-bezier(.22,.9,.36,1) forwards;
      }
      #pv-guide-card.pv-card-exit {
        animation: pvCardOut .25s ease-in forwards;
      }
      @keyframes pvCardIn {
        from { opacity:0; transform: scale(.92) translateY(8px); }
        to   { opacity:1; transform: scale(1)  translateY(0);    }
      }
      @keyframes pvCardOut {
        from { opacity:1; transform: scale(1)  translateY(0);    }
        to   { opacity:0; transform: scale(.92) translateY(8px); }
      }

      /* Card inner sections */
      .pv-card-header {
        background: linear-gradient(135deg, #0055b8, #1a73e8);
        border-radius: 10px 10px 0 0;
        padding: 11px 14px 10px;
        display: flex; align-items: center; gap: 8px;
      }
      .pv-card-header-icon {
        font-size: 18px; color: #fff; flex-shrink: 0;
      }
      .pv-card-header-title {
        font-size: 13px; font-weight: 700; color: #fff; line-height: 1.25;
      }
      .pv-card-header-sub {
        font-size: 10.5px; color: rgba(255,255,255,.8); margin-top:1px;
      }
      .pv-card-body { padding: 12px 14px 10px; }
      .pv-card-desc {
        font-size: 12px; color: #3c4043; line-height: 1.5; margin-bottom: 8px;
      }
      .pv-card-example {
        background: #f1f3f4; border-radius: 6px;
        padding: 7px 10px; margin-bottom: 10px;
      }
      .pv-card-example-label {
        font-size: 10px; font-weight: 700; color: #5f6368;
        text-transform: uppercase; letter-spacing: .5px; margin-bottom:3px;
      }
      .pv-card-example-val {
        font-size: 11px; font-family: "Roboto Mono", "Courier New", monospace;
        color: #174ea6; word-break: break-all; line-height:1.4;
      }
      .pv-card-footer {
        border-top: 1px solid #e8eaed;
        padding: 8px 14px;
        display: flex; align-items: center; justify-content: space-between;
        gap: 8px;
      }
      .pv-card-hint {
        font-size: 10.5px; color: #80868b; flex: 1;
      }
      .pv-card-done-btn {
        background: #0055b8; color: #fff;
        border: none; border-radius: 6px;
        padding: 5px 12px; font-size: 11.5px; font-weight: 600;
        cursor: pointer; flex-shrink: 0;
        transition: background .15s;
      }
      .pv-card-done-btn:hover { background: #1a73e8; }

      /* Vernacular language toggle + text-to-speech controls */
      .pv-card-lang-row {
        display: flex; align-items: center; gap: 5px;
        padding: 7px 14px; background: #f1f3f4;
        border-bottom: 1px solid #e8eaed;
      }
      .pv-lang-btn {
        background: #fff; color: #0055b8;
        border: 1px solid #c9d7ee; border-radius: 20px;
        padding: 2px 10px; font-size: 10.5px; font-weight: 600;
        cursor: pointer; transition: background .15s, color .15s;
      }
      .pv-lang-btn:hover { background: #eaf1fd; }
      .pv-lang-btn-active { background: #0055b8; color: #fff; border-color: #0055b8; }
      .pv-tts-btn {
        background: #fff; border: 1px solid #c9d7ee;
        border-radius: 50%; width: 24px; height: 24px; line-height: 1;
        font-size: 12px; cursor: pointer; flex-shrink: 0;
        display: flex; align-items: center; justify-content: center;
        transition: background .15s; margin-left: auto;
      }
      .pv-tts-btn:hover { background: #eaf1fd; }

      /* SVG connector line */
      #pv-guide-svg {
        position: absolute;
        z-index: 2147483639;
        pointer-events: none;
        overflow: visible;
        top: 0; left: 0;
      }
      #pv-guide-svg .pv-connector {
        stroke: #0055b8;
        stroke-width: 2;
        fill: none;
        stroke-dasharray: 6 4;
        animation: pvDash 1.2s linear infinite;
      }
      @keyframes pvDash {
        to { stroke-dashoffset: -20; }
      }

      /* Backdrop dim for target area */
      #pv-guide-backdrop {
        position: fixed; inset: 0;
        background: rgba(0,0,0,.18);
        z-index: 2147483630;
        pointer-events: none;
        animation: pvFadeIn .3s ease forwards;
      }
      #pv-guide-spotlight {
        position: absolute;
        border-radius: 6px;
        box-shadow: 0 0 0 9999px rgba(0,0,0,.18);
        pointer-events: none;
        transition: all .35s cubic-bezier(.22,.9,.36,1);
      }
      @keyframes pvFadeIn {
        from { opacity:0; } to { opacity:1; }
      }

      /* Step progress dots */
      .pv-step-dots {
        display: flex; gap: 5px; align-items: center; padding: 0 14px 9px;
      }
      .pv-dot {
        width: 6px; height: 6px; border-radius: 50%;
        background: #dadce0; transition: background .2s, transform .2s;
      }
      .pv-dot.active { background: #0055b8; transform: scale(1.3); }
    `;
    document.head.appendChild(s);
  }

  // ── Build a rich description for a field ──────────────────────────────────
  function buildFieldInfo(fieldName, expectedValue, inputType) {
    const name = (fieldName || '').toLowerCase();
    const sel  = (expectedValue || '').toLowerCase();

    if (name.includes('pan') || sel.includes('pan')) {
      return {
        key: 'pan',
        icon: '🪪',
        title: 'PAN Card Number',
        subtitle: 'Permanent Account Number',
        desc: 'Enter your 10-character Permanent Account Number exactly as printed on your PAN card — no spaces.',
        example: 'ABCDE1234F',
        hint: 'Format: 5 letters · 4 digits · 1 letter'
      };
    }
    if (name.includes('aadhaar') || name.includes('aadhar')) {
      return {
        key: 'aadhaar',
        icon: '🪪',
        title: 'Aadhaar Number',
        subtitle: 'UIDAI 12-digit ID',
        desc: 'Enter your 12-digit Aadhaar number. You can find this on your Aadhaar card or e-Aadhaar PDF.',
        example: '1234 5678 9012',
        hint: 'Spaces are optional — enter digits only if unsure'
      };
    }
    if (name.includes('upi') || name.includes('vpa')) {
      return {
        key: 'upi',
        icon: '💳',
        title: 'UPI PIN / VPA',
        subtitle: 'Unified Payments Interface',
        desc: 'Enter your UPI Virtual Payment Address or 4/6-digit UPI PIN as registered with your bank app.',
        example: 'yourname@upi',
        hint: 'PIN is never stored or transmitted'
      };
    }
    if (name.includes('email') || inputType === 'email') {
      return {
        key: 'email',
        icon: '✉️',
        title: 'Email Address',
        subtitle: 'Your registered email',
        desc: 'Enter the email address associated with your account. It should be in standard email format.',
        example: 'yourname@example.com',
        hint: 'Must contain @ and a valid domain'
      };
    }
    if (name.includes('phone') || name.includes('mobile') || inputType === 'tel') {
      return {
        key: 'phone',
        icon: '📱',
        title: 'Mobile Number',
        subtitle: 'Registered phone number',
        desc: 'Enter your 10-digit mobile number without country code or spaces.',
        example: '9876543210',
        hint: 'Do not include +91 or leading zeros'
      };
    }
    if (name.includes('pass') || inputType === 'password') {
      return {
        key: 'password',
        icon: '🔒',
        title: 'Password',
        subtitle: 'Your account password',
        desc: 'Enter your account password. It will not be stored, logged, or sent to any server — it is typed directly into the page.',
        example: '(your secret password)',
        hint: 'Entered directly on the page, never captured'
      };
    }
    if (name.includes('dob') || name.includes('birth') || inputType === 'date') {
      return {
        key: 'dob',
        icon: '📅',
        title: 'Date of Birth',
        subtitle: 'As on official documents',
        desc: 'Enter your date of birth in the format shown by the field — typically DD/MM/YYYY or YYYY-MM-DD.',
        example: '15/08/1995',
        hint: 'Use the date picker or type in the required format'
      };
    }
    if (name.includes('name')) {
      return {
        key: 'name',
        icon: '👤',
        title: 'Full Name',
        subtitle: 'As on official documents',
        desc: 'Enter your full legal name exactly as it appears on your government-issued ID or bank records.',
        example: 'Rohit Dhade',
        hint: 'Avoid nicknames or abbreviations'
      };
    }
    if (name.includes('ifsc')) {
      return {
        key: 'ifsc',
        icon: '🏦',
        title: 'IFSC Code',
        subtitle: 'Bank branch identifier',
        desc: 'Enter the 11-character IFSC code of your bank branch. You can find it on your cheque book or bank passbook.',
        example: 'SBIN0001234',
        hint: 'Format: 4 letters · 0 · 6 digits/letters'
      };
    }
    if (name.includes('account') || name.includes('acc no')) {
      return {
        key: 'account',
        icon: '🏦',
        title: 'Account Number',
        subtitle: 'Bank account number',
        desc: 'Enter your full bank account number without spaces or dashes, as listed on your passbook.',
        example: '00001234567890',
        hint: 'Usually 9–18 digits depending on your bank'
      };
    }
    // generic fallback
    return {
      key: 'generic',
      icon: '✏️',
      title: fieldName || 'Required Field',
      subtitle: 'Agent needs your input',
      desc: expectedValue || 'Please enter the required value directly into this field on the page.',
      example: null,
      hint: 'Type directly into the highlighted field'
    };
  }

  // ── Core guide renderer ────────────────────────────────────────────────────
  function showFieldGuide(el, fieldName, expectedValue, inputType, onDone) {
    ensureGuideStyles();

    // Clean up any previous guide
    _removeGuideDOM();

    el.scrollIntoView({ behavior: 'smooth', block: 'center' });

    const info = buildFieldInfo(fieldName, expectedValue, inputType);

    // Vernacular support: build a small { langTag -> { title, subtitle,
    // desc, hint } } map so low-literacy / non-English-fluent users (the
    // realistic user base for a government KYC flow) can toggle the
    // callout card into their own language, and optionally have it read
    // aloud via the browser's native speechSynthesis API. English is
    // always available (it's what buildFieldInfo() already returns);
    // additional languages come from utils/i18nLabels.js's static
    // lookup table, keyed by the same `info.key`.
    const translations = {
      'en-IN': { label: 'EN', title: info.title, subtitle: info.subtitle, desc: info.desc, hint: info.hint }
    };
    if (window.__BA_I18nLabels && window.__BA_I18nLabels.LANGUAGES) {
      for (const [langTag, lang] of Object.entries(window.__BA_I18nLabels.LANGUAGES)) {
        const t = window.__BA_I18nLabels.getTranslation(langTag, info.key);
        if (t) translations[langTag] = { label: lang.label, ...t };
      }
    }
    const languageOrder = Object.keys(translations);
    let activeLang = 'en-IN';

    // 1. Spotlight backdrop
    const backdrop = document.createElement('div');
    backdrop.id = 'pv-guide-backdrop';
    document.body.appendChild(backdrop);

    const spotlight = document.createElement('div');
    spotlight.id = 'pv-guide-spotlight';
    backdrop.appendChild(spotlight);

    function updateSpotlight() {
      const r = el.getBoundingClientRect();
      const pad = 6;
      spotlight.style.left   = `${r.left - pad}px`;
      spotlight.style.top    = `${r.top  - pad}px`;
      spotlight.style.width  = `${r.width  + pad * 2}px`;
      spotlight.style.height = `${r.height + pad * 2}px`;
    }
    updateSpotlight();

    // 2. Pulsing outline on element
    el.classList.add('pv-field-active');
    setTimeout(() => el.focus(), 200);

    // 3. Build callout card
    const card = document.createElement('div');
    card.id = 'pv-guide-card';
    const langPillsHtml = languageOrder.length > 1
      ? languageOrder.map((lt) => `<button type="button" class="pv-lang-btn${lt === activeLang ? ' pv-lang-btn-active' : ''}" data-lang="${lt}">${escapeHtml(translations[lt].label)}</button>`).join('')
      : '';

    card.innerHTML = `
      <div class="pv-card-header">
        <span class="pv-card-header-icon">${info.icon}</span>
        <div style="flex:1; min-width:0;">
          <div class="pv-card-header-title" id="pv-guide-title">${escapeHtml(info.title)}</div>
          <div class="pv-card-header-sub" id="pv-guide-subtitle">${escapeHtml(info.subtitle)}</div>
        </div>
      </div>
      <div class="pv-card-lang-row" id="pv-guide-lang-row">
        ${langPillsHtml}
        <button type="button" class="pv-tts-btn" id="pv-guide-tts-btn" title="Read this field aloud" aria-label="Read this field aloud">🔊</button>
      </div>
      <div class="pv-card-body">
        <div class="pv-card-desc" id="pv-guide-desc">${escapeHtml(info.desc)}</div>
        ${info.example ? `
          <div class="pv-card-example">
            <div class="pv-card-example-label">Example</div>
            <div class="pv-card-example-val">${escapeHtml(info.example)}</div>
          </div>` : ''}
      </div>
      <div class="pv-card-footer">
        <span class="pv-card-hint" id="pv-guide-hint">💡 ${escapeHtml(info.hint)}</span>
        <button class="pv-card-done-btn" id="pv-guide-done-btn">Done ✓</button>
      </div>
    `;
    document.body.appendChild(card);

    // 3B. Vernacular language toggle + text-to-speech wiring.
    // Pure client-side text swap (no re-render) so the spotlight/connector
    // positioning logic below is unaffected by the language change.
    const titleEl    = card.querySelector('#pv-guide-title');
    const subtitleEl = card.querySelector('#pv-guide-subtitle');
    const descEl     = card.querySelector('#pv-guide-desc');
    const hintEl     = card.querySelector('#pv-guide-hint');

    function applyLanguage(langTag) {
      const t = translations[langTag];
      if (!t) return;
      activeLang = langTag;
      if (titleEl) titleEl.textContent = t.title;
      if (subtitleEl) subtitleEl.textContent = t.subtitle;
      if (descEl) descEl.textContent = t.desc;
      if (hintEl) hintEl.textContent = `💡 ${t.hint}`;
      card.querySelectorAll('.pv-lang-btn').forEach((btn) => {
        btn.classList.toggle('pv-lang-btn-active', btn.dataset.lang === langTag);
      });
    }

    card.querySelectorAll('.pv-lang-btn').forEach((btn) => {
      btn.addEventListener('click', () => applyLanguage(btn.dataset.lang));
    });

    const ttsBtn = card.querySelector('#pv-guide-tts-btn');
    if (ttsBtn) {
      if (typeof window.speechSynthesis === 'undefined' || typeof window.SpeechSynthesisUtterance === 'undefined') {
        ttsBtn.style.display = 'none';
      } else {
        ttsBtn.addEventListener('click', () => {
          try {
            window.speechSynthesis.cancel(); // stop any previous utterance first
            const t = translations[activeLang];
            const utterance = new window.SpeechSynthesisUtterance(`${t.title}. ${t.desc}`);
            utterance.lang = activeLang;
            window.speechSynthesis.speak(utterance);
          } catch (e) {
            console.debug('[BA] speechSynthesis unavailable:', e.message);
          }
        });
      }
    }
    card.classList.add('pv-card-enter');

    // 4. Position card (prefer right side of element, fall back to top/bottom)
    function positionCard() {
      const r   = el.getBoundingClientRect();
      const vw  = window.innerWidth;
      const vh  = window.innerHeight;
      const cw  = 310; // card width
      const ch  = card.offsetHeight || 200;
      let   cx, cy;

      const spaceRight  = vw - r.right - 20;
      const spaceLeft   = r.left - 20;
      const spaceTop    = r.top - 20;
      const spaceBottom = vh - r.bottom - 20;

      if (spaceRight >= cw) {
        cx = window.scrollX + r.right + 16;
        cy = window.scrollY + r.top + (r.height - ch) / 2;
      } else if (spaceLeft >= cw) {
        cx = window.scrollX + r.left - cw - 16;
        cy = window.scrollY + r.top + (r.height - ch) / 2;
      } else if (spaceTop >= ch) {
        cx = window.scrollX + r.left + (r.width - cw) / 2;
        cy = window.scrollY + r.top - ch - 16;
      } else {
        cx = window.scrollX + r.left + (r.width - cw) / 2;
        cy = window.scrollY + r.bottom + 16;
      }

      // Clamp inside viewport
      cx = Math.max(window.scrollX + 10, Math.min(cx, window.scrollX + vw - cw - 10));
      cy = Math.max(window.scrollY + 10, cy);

      card.style.left  = `${cx}px`;
      card.style.top   = `${cy}px`;
      card.style.width = `${cw}px`;

      return { cx, cy, cw, ch: card.offsetHeight };
    }
    setTimeout(positionCard, 0);

    // 5. SVG animated dashed connector line
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.id = 'pv-guide-svg';
    svg.style.width  = '1px';
    svg.style.height = '1px';
    document.body.appendChild(svg);

    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('class', 'pv-connector');
    svg.appendChild(path);

    // Arrowhead marker
    const defs   = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    const marker = document.createElementNS('http://www.w3.org/2000/svg', 'marker');
    marker.setAttribute('id', 'pv-arrow');
    marker.setAttribute('markerWidth', '8');
    marker.setAttribute('markerHeight', '8');
    marker.setAttribute('refX', '6');
    marker.setAttribute('refY', '3');
    marker.setAttribute('orient', 'auto');
    const arrowPoly = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
    arrowPoly.setAttribute('points', '0 0, 8 3, 0 6');
    arrowPoly.setAttribute('fill', '#0055b8');
    marker.appendChild(arrowPoly);
    defs.appendChild(marker);
    svg.appendChild(defs);
    path.setAttribute('marker-end', 'url(#pv-arrow)');

    function drawConnector() {
      const r  = el.getBoundingClientRect();
      const cr = card.getBoundingClientRect();

      // Start: closest card edge midpoint; End: element midpoint
      const ex = window.scrollX + r.left + r.width  / 2;
      const ey = window.scrollY + r.top  + r.height / 2;
      const cx = window.scrollX + (cr.left + cr.width  / 2);
      const cy = window.scrollY + (cr.top  + cr.height / 2);

      // Choose start from card edge nearest element
      let sx, sy;
      if (cr.right < r.left) {
        sx = window.scrollX + cr.right; sy = window.scrollY + cr.top + cr.height / 2;
      } else if (cr.left > r.right) {
        sx = window.scrollX + cr.left; sy = window.scrollY + cr.top + cr.height / 2;
      } else if (cr.bottom < r.top) {
        sx = cx; sy = window.scrollY + cr.bottom;
      } else {
        sx = cx; sy = window.scrollY + cr.top;
      }

      const dx = ex - sx;
      const dy = ey - sy;
      const d  = `M ${sx} ${sy} C ${sx + dx * .4} ${sy}, ${ex - dx * .3} ${ey}, ${ex} ${ey}`;
      path.setAttribute('d', d);

      // Resize SVG to cover area
      const minX = Math.min(sx, ex) - 20;
      const minY = Math.min(sy, ey) - 20;
      const maxX = Math.max(sx, ex) + 20;
      const maxY = Math.max(sy, ey) + 20;
      svg.setAttribute('viewBox', `${minX} ${minY} ${maxX - minX} ${maxY - minY}`);
      svg.style.left   = `${minX}px`;
      svg.style.top    = `${minY}px`;
      svg.style.width  = `${maxX - minX}px`;
      svg.style.height = `${maxY - minY}px`;
    }

    let rafId;
    function rafLoop() {
      updateSpotlight();
      positionCard();
      drawConnector();
      rafId = requestAnimationFrame(rafLoop);
    }
    // Only run RAF for a short time to settle, then stop (performance)
    rafId = requestAnimationFrame(rafLoop);
    setTimeout(() => cancelAnimationFrame(rafId), 600);

    // 6. Done handler
    function handleDone() {
      _removeGuideDOM();
      if (typeof onDone === 'function') onDone();
    }

    const doneBtn = document.getElementById('pv-guide-done-btn');
    if (doneBtn) doneBtn.addEventListener('click', handleDone, { once: true });
    el.addEventListener('change', handleDone, { once: true });

    // Store cleanup reference
    window.__BA_state.guideCleanup = handleDone;
    return { success: true };
  }

  function _removeGuideDOM() {
    cancelAnimationFrame(window.__BA_state._guideRaf);
    ['pv-guide-card', 'pv-guide-svg', 'pv-guide-backdrop'].forEach((id) => {
      document.getElementById(id)?.remove();
    });
    document.querySelectorAll('.pv-field-active').forEach((e) => e.classList.remove('pv-field-active'));
    window.__BA_state.guideCleanup = null;
  }

  // ── Public BrowserAgent API ────────────────────────────────────────────────
  const BrowserAgent = {
    runFullExtraction(taskInstruction = '') {
      const result = window.__BA_DomExtractor.runExtraction();
      result.userInteractions = BrowserAgent.getRecentUserInteractions();

      // Shadow mode: build Smart Semantic DOM for local inspection only.
      // Does NOT affect the production result or any outbound payload.
      if (window.__BA_SemanticDom) {
        try {
          const t0 = performance.now();
          const shadow = window.__BA_SemanticDom.buildSemanticView(
            result.elements,
            result.url,
            result.pageContext,
            result.visibleText,
            taskInstruction || ''
          );
          shadow.buildTimeMs = Math.round(performance.now() - t0);
          window.__BA_state.shadowSemanticDom = shadow;
          console.debug('[SemanticDOM:Shadow]', shadow.stats, shadow.contextSummary);
        } catch (e) {
          console.debug('[SemanticDOM:Shadow] Error:', e.message);
        }
      }

      return result;
    },
    getLastResult() { return window.__BA_state.lastResult; },

    getRecentUserInteractions() {
      const interactions = Array.isArray(window.__BA_state.userInteractions)
        ? [...window.__BA_state.userInteractions]
        : [];
      window.__BA_state.userInteractions = [];
      return interactions;
    },

    click(elementId, targetSelector) {
      const el = resolveElement(elementId, targetSelector);
      if (!el) return { success: false, reason: 'element_not_found' };
      if (!window.__BA_Visibility.isElementVisible(el, window.innerWidth, window.innerHeight))
        return { success: false, reason: 'element_not_visible' };
      
      const preUrl = location.href;
      const preChecked = el.checked;
      const preExpanded = el.getAttribute('aria-expanded');

      el.scrollIntoView({ block: 'center', inline: 'center' });
      el.click();

      const postChecked = el.checked;
      const postExpanded = el.getAttribute('aria-expanded');
      const postUrl = location.href;

      return {
        success: true,
        verified: true,
        stateChange: {
          urlChanged: preUrl !== postUrl,
          checkedChanged: preChecked !== postChecked,
          expandedChanged: preExpanded !== postExpanded,
          postChecked: postChecked ?? null
        }
      };
    },

    type(elementId, text, optionsOrSelector = {}) {
      const targetSelector = typeof optionsOrSelector === 'string'
        ? optionsOrSelector
        : (optionsOrSelector?.targetSelector || null);
      const el = resolveElement(elementId, targetSelector);
      if (!el) return { success: false, reason: 'element_not_found' };
      if (!window.__BA_Visibility.isElementVisible(el, window.innerWidth, window.innerHeight))
        return { success: false, reason: 'element_not_visible' };
      const tag = el.tagName.toLowerCase();
      if (tag !== 'input' && tag !== 'textarea') return { success: false, reason: 'element_not_typeable' };
      
      const prevValue = el.value || '';
      
      // If element already has the exact expected value, mark verified without redundant typing
      if (prevValue === text) {
        return { success: true, verified: true, unchanged: true, value: text };
      }

      el.focus();
      dispatchNativeInput(el, text);

      const currentValue = el.value || '';
      const verified = currentValue === text || currentValue.length > 0;

      return {
        success: true,
        verified,
        previousValue: prevValue.length > 0 ? '[PREVIOUS_VALUE]' : '',
        hasValue: currentValue.length > 0
      };
    },

    fill(elementId, text, options = {}) {
      return this.type(elementId, text, options);
    },

    clear(elementId, targetSelector) {
      const el = resolveElement(elementId, targetSelector);
      if (!el) return { success: false, reason: 'element_not_found' };
      const tag = el.tagName.toLowerCase();
      if (tag !== 'input' && tag !== 'textarea') return { success: false, reason: 'element_not_typeable' };

      el.focus();
      dispatchNativeInput(el, '');
      return { success: true, verified: el.value === '', value: '' };
    },

    check(elementId, shouldCheck = true, targetSelector) {
      const el = resolveElement(elementId, targetSelector);
      if (!el) return { success: false, reason: 'element_not_found' };
      
      const targetState = Boolean(shouldCheck);
      if (el.checked !== targetState) {
        el.checked = targetState;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      }
      return { success: true, verified: el.checked === targetState, checked: el.checked };
    },

    hover(elementId, targetSelector) {
      const el = resolveElement(elementId, targetSelector);
      if (!el) return { success: false, reason: 'element_not_found' };

      el.scrollIntoView({ block: 'center', inline: 'center' });
      el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
      el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
      el.dispatchEvent(new MouseEvent('mousemove', { bubbles: true }));

      return { success: true, verified: true };
    },

    focus(elementId, targetSelector) {
      const el = resolveElement(elementId, targetSelector);
      if (!el) return { success: false, reason: 'element_not_found' };

      el.scrollIntoView({ block: 'center', inline: 'center' });
      el.focus();
      el.dispatchEvent(new FocusEvent('focusin', { bubbles: true }));
      return { success: true, verified: document.activeElement === el };
    },

    press_key(elementId, keyName = 'Enter', targetSelector) {
      const el = (elementId != null || targetSelector) ? resolveElement(elementId, targetSelector) : document.activeElement || document.body;
      if (!el) return { success: false, reason: 'target_not_found' };

      const key = String(keyName);
      const preUrl = location.href;

      el.dispatchEvent(new KeyboardEvent('keydown', { key, code: key, bubbles: true, cancelable: true }));
      el.dispatchEvent(new KeyboardEvent('keypress', { key, code: key, bubbles: true, cancelable: true }));
      el.dispatchEvent(new KeyboardEvent('keyup', { key, code: key, bubbles: true, cancelable: true }));

      // If Enter in form input, submit form if native
      if (key.toLowerCase() === 'enter' && el.form) {
        try { el.form.requestSubmit(); } catch (_) {}
      }

      return {
        success: true,
        verified: true,
        stateChange: {
          urlChanged: preUrl !== location.href
        }
      };
    },

    scroll(direction, amount = 400, targetSelector) {
      if (targetSelector) {
        const container = document.querySelector(targetSelector);
        if (container) {
          const preTop = container.scrollTop;
          const scrollDelta = direction === 'up' ? -amount : amount;
          container.scrollBy({ top: scrollDelta, behavior: 'instant' });
          const postTop = container.scrollTop;
          const didScroll = preTop !== postTop;
          return {
            success: true,
            verified: didScroll,
            didScroll,
            preTop,
            postTop,
            container: targetSelector,
            direction,
            amount
          };
        }
      }

      const preY = window.scrollY;
      const preX = window.scrollX;
      const scrollDelta = direction === 'up' ? -amount : amount;
      
      window.scrollBy({ top: scrollDelta, behavior: 'instant' });
      const postY = window.scrollY;
      const didScroll = preY !== postY;

      return {
        success: true,
        verified: didScroll,
        didScroll,
        preY,
        postY,
        preX,
        direction,
        amount
      };
    },

    navigate(url) {
      if (!url || typeof url !== 'string') return { success: false, reason: 'invalid_url' };
      location.href = url;
      return { success: true, verified: true, navigatingTo: url };
    },

    back() {
      history.back();
      return { success: true, verified: true };
    },

    forward() {
      history.forward();
      return { success: true, verified: true };
    },

    extract(elementId, targetSelector) {
      const el = (elementId != null || targetSelector) ? resolveElement(elementId, targetSelector) : document.body;
      if (!el) return { success: false, reason: 'element_not_found' };
      const extractedText = (el.innerText || el.textContent || '').trim();
      return { success: true, verified: true, text: extractedText };
    },

    select(elementId, optionValue, targetSelector) {
      const el = resolveElement(elementId, targetSelector);
      if (!el || el.tagName.toLowerCase() !== 'select')
        return { success: false, reason: 'element_not_found_or_not_select' };
      
      const preValue = el.value;
      const normalizedTarget = String(optionValue || '').trim().toLowerCase();
      
      // Match option by value or by visible text
      let matchedOption = Array.from(el.options).find(opt => 
        opt.value === optionValue || 
        opt.value.toLowerCase() === normalizedTarget ||
        opt.text.trim().toLowerCase() === normalizedTarget
      );

      if (matchedOption) {
        el.value = matchedOption.value;
      } else {
        el.value = optionValue;
      }

      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));

      const postValue = el.value;
      const verified = postValue === (matchedOption ? matchedOption.value : optionValue);

      return {
        success: true,
        verified,
        preValue,
        selectedValue: postValue
      };
    },

    highlightField(elementId, fieldName, expectedValue) {
      const el = resolveElement(elementId);
      if (!el) return { success: false, reason: 'element_not_found' };

      const inputType = el.getAttribute('type') || el.tagName.toLowerCase();
      const isFileInput = inputType === 'file';
      const isRadio     = inputType === 'radio';
      const isSelect    = el.tagName.toLowerCase() === 'select';
      const isCheckbox  = inputType === 'checkbox';

      // For file inputs: override description to guide user to click and select
      let effectiveField    = fieldName;
      let effectiveExpected = expectedValue;

      if (isFileInput) {
        effectiveField    = fieldName || 'Upload File';
        effectiveExpected = expectedValue || 'Click this button to open the file picker and select the required file from your device.';
      } else if (isRadio) {
        effectiveField    = fieldName || 'Select an Option';
        effectiveExpected = expectedValue || 'Click the correct radio button to select your choice.';
      } else if (isSelect) {
        effectiveField    = fieldName || 'Select from Dropdown';
        effectiveExpected = expectedValue || 'Click the dropdown and choose the appropriate option from the list.';
      } else if (isCheckbox) {
        effectiveField    = fieldName || 'Check / Uncheck';
        effectiveExpected = expectedValue || 'Click the checkbox to enable or disable this option.';
      }

      showFieldGuide(el, effectiveField, effectiveExpected, inputType, null);
      return { success: true };
    },

    clearHighlight() {
      _removeGuideDOM();
      return { success: true };
    },

    startObserving() {
      if (window.__BA_state.observer) return;
      const observer = new MutationObserver(() => {
        clearTimeout(window.__BA_state.debounceTimer);
        window.__BA_state.debounceTimer = setTimeout(() => {
          try { window.__BA_DomExtractor.runExtraction(); } catch (e) {}
        }, 400);
      });
      observer.observe(document.body, { childList: true, subtree: true, attributes: true });
      window.__BA_state.observer = observer;
    },

    stopObserving() {
      if (window.__BA_state.observer) {
        window.__BA_state.observer.disconnect();
        window.__BA_state.observer = null;
      }
    }
  };

  window.__BA = BrowserAgent;
})(window);