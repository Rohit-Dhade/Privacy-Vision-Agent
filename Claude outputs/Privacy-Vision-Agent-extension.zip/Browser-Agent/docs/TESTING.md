# Testing

This extension has two genuinely different kinds of verification available, and they cover different, non-overlapping parts of the system. Neither one alone tells you the whole system works — read both scope sections below before citing either as "tested."

## 1. The automated benchmark harness (`benchmark/run-benchmark.js`)

```
node benchmark/run-benchmark.js
```

No `npm install` needed — zero dependencies beyond Node itself, deliberately, so another team can clone this and run it against their own implementation of the same detectors. It loads the extension's own, unmodified source files directly under Node — no mocking of the module under test, only of the things that genuinely require a browser (see scope below) — runs them against hand-labeled fixtures in `benchmark/fixtures/`, and writes `benchmark/results/latest-results.json` and `.md`.

### What it covers

| Section | What it actually exercises |
|---|---|
| Sensitive data detection | `content/piiDetector.js`'s full regex + checksum layer: Luhn (cards, Canada SIN), Verhoeff (Aadhaar), ISO 7064 mod-97-10 (IBAN, Germany VAT) / mod-89-style (Australia ABN), ICAO 9303 (passport MRZ), GB 11643-1999 (China resident ID), Japan's My Number check digit, Brazil's CPF two-check-digit algorithm, Australia's TFN mod-11 check, the SSA's SSN exclusion rules, Shannon-entropy secret detection, plus several disclosed format-only (no public checksum) types — UK NINO, Mexico CURP/RFC. 38 hand-labeled cases as of this writing. |
| Local field-matching accuracy | `agent/fieldMatcher.js`'s label/type/regex resolution. |
| Consequential-action safety gate | `agent/consequentialActionDetector.js`'s classification — a hard safety requirement independent of any weighted scoring category, since a false negative here means an unauthorized real-world action. |
| Redaction integrity | Cryptographic self-consistency of `utils/merkleProof.js` against synthetic pixel data — does a valid proof verify, and does tampering with the root, a tile hash, or the signature get caught. This is *not* IoU against a labeled real-image dataset (the harness has no images); it measures whether the "redacted before it left the browser" cryptographic guarantee holds, not redaction accuracy itself. |
| Hybrid Debate resolution logic | `agent/debateManager.js`'s agree/disagree/degraded resolution tiers plus `agent/confidenceScorer.js`'s scoring, against mocked local/cloud reasoner responses (`benchmark/fixtures/debate-scenarios.js`) — only `agentBackend`'s two decision-source methods are mocked; `debateManager.js` and `confidenceScorer.js` run unmodified. Discrete pass/fail checks, not precision/recall, since each scenario asserts one specific resolution outcome. |
| Local screen-state perception | `utils/visualStateEngine.js` against synthetic scenes with known ground truth, including deliberate false-positive traps (dark theme, dark chrome, scroll) that a naive detector would misclassify as a modal. |
| Local icon classification | The shipped JS inference path (`utils/iconClassifier.js` + `utils/iconModel.js`) against held-out synthetic icon crops, reporting coverage and precision-when-answering separately since the classifier is allowed to decline. |

### What it deliberately does not cover

The ONNX NER pass, on-device OCR, face detection, and the cloud VLM's visual reasoning all require a real browser (offscreen document, canvas, WASM/WebGPU runtime) this Node harness does not simulate. Rather than mock these into a misleading "pass," the harness stubs the NER call to resolve as unavailable — exactly how the real extension degrades if the model fails to load — and every section's `scope` field in the output states plainly what actually ran. Separately (see `IMPLEMENTATION.md`), the NER model's actual weights (`models/ner/model_quantized.onnx`) aren't present in this repo at all right now, so this isn't only a Node-vs-browser gap for NER specifically — it would fail closed in a real browser today too, for an unrelated reason (a missing file, not a missing runtime).

`agent/decisionRouter.js`, `agent/complianceChecker.js`, and `agent/contextManager.js` each have their own standalone unit tests (written during their implementation, not part of `run-benchmark.js`) exercising their public API against fakes/mocks. `decisionRouter.js` and `complianceChecker.js` are now also wired into `popup.js` (see `IMPLEMENTATION.md`) — Hybrid mode's per-step decision and every page analysis's compliance panel, respectively — so their standalone tests plus this harness's own re-run after wiring cover their logic, but neither has been exercised inside an actual loaded Chrome extension (see "Manual browser verification" below). `contextManager.js` remains unwired, so its tests verify the module in isolation only.

### This is a small, hand-authored fixture set, and it already found real bugs

The fixture files are dozens of cases each, not thousands. This demonstrates methodology and catches regressions; it is not a claim of statistically robust dataset coverage. It is also not a rigged demo — several fixtures were written specifically to probe cases the system was expected to handle correctly, and running this harness for the first time caught a genuine off-by-one bug in `utils/merkleProof.js`'s tile-boundary math (fixed the same day, directly because the harness exists). A second, previously-published finding — a spurious extra `PHONE` label on already-correctly-classified IDs, which used to drag the PII section's measured precision down to ~42% even at 100% recall — was fixed by `content/piiDetector.js`'s range-claim tracker and is confirmed resolved: the section now runs at 100%/100%/100%. See `benchmark/README.md` for the full history, including the one inherent (not-a-bug) ambiguity: a bare 9-digit number can coincidentally satisfy both Canada's SIN checksum and Australia's TFN checksum at once (about a 1-in-100 chance), in which case whichever detector runs first claims the label — the number is still correctly flagged as sensitive and redacted either way, only the specific country label can be ambiguous.

### Contributing a fixture

Add a case to the relevant `benchmark/fixtures/*.json` file following the existing shape and re-run the script — no code changes needed for a new test case, only for a new category of check. The ground truth used (real IBAN/MRZ/Aadhaar/CPF/ABN/etc. checksum test vectors, real Luhn-valid numbers) is standards-based, not specific to this implementation, so another team's equivalent detectors can be pointed at the same fixture files for a comparable report.

## 2. Manual browser verification

The benchmark harness cannot exercise anything that needs an actual Chrome extension context — the side panel UI, the offscreen document's WASM/WebGPU models, real screenshot capture, real DOM injection into a live page, or the Privacy Dial's actual behavior end to end. That verification requires loading the unpacked extension in Chrome (see `DEPLOYMENT.md`) and working through it by hand:

- Load a real form (a demo page, or a real site) and confirm PII on it is actually redacted in the captured screenshot, not just detected in the data structure.
- Walk through all four Privacy Dial modes on the same page and confirm the Privacy Receipt panel's transmission log matches what each mode claims: zero transmissions in `local` mode; one cloud call per step in `cloud` mode; in `hybrid` mode, a cloud call only on steps the routing-stats line reports as `CLOUD` (confirm the TREE/HEURISTIC/LOCAL_LLM-resolved steps show no transmission at all); both a local attempt and a cloud call in `debate`, with the evidence panel showing agreement/disagreement correctly.
- In `hybrid` mode specifically, confirm the "Local Decision Routing" line in the Privacy Receipt panel updates after each step and that its layer counts add up to the number of steps taken so far.
- Confirm the "Compliance Signals" panel updates after each page analysis (all four modes) and that its score/violation list changes sensibly between a page with no forms and one with a form collecting several PII types.
- Trigger a consequential action (a submit/payment-labeled button) and confirm all 9 authorization steps actually happen in order, including that the authorization token is refused a second use.
- Download a redaction proof from the Privacy Receipt panel and independently verify it with `tools/verify-redaction-proof.html`, without the extension in the loop.

None of this has been performed as part of the current documentation/PII-expansion/decision-router/compliance-checker/context-manager/wiring work — that work, including wiring `decisionRouter.js` and `complianceChecker.js` into `popup.js`, was built and unit-tested/syntax-checked against Node, per the scope notes above, in a sandboxed environment with no Chrome available. Treat this section as a checklist for the next real-browser pass, not a report of one already done. Prior real-browser runs (see `claude/v14-first-real-browser-run.md` and `claude/v17-*`/`v19-*` in the project's own doc history) did happen for earlier parts of this system; the newer pieces documented here (the multi-jurisdiction PII pack, `decisionRouter.js`'s and `complianceChecker.js`'s new wiring into the loop, `contextManager.js`) have not yet had that pass.
