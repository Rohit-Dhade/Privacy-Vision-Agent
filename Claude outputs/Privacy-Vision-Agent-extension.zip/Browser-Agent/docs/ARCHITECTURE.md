# Architecture

This describes the system as it actually runs today, not as originally planned. Where a piece exists in the codebase but isn't wired into the running extension yet, that's called out explicitly rather than implied. See `IMPLEMENTATION.md` for a file-by-file inventory and `claude/v25-master-implementation-guide.md` (in the project's docs, not in this repo) for the original design roadmap this was built against.

## The four surfaces

A Manifest V3 extension has no single "main program" — it's four separate JavaScript execution contexts that talk to each other through message passing and, in one case, direct function injection:

- **Content scripts** (`content/*.js`) run inside the actual web page, in every frame. They're injected twice, by two independent mechanisms that overlap on one file — see "Two injection paths" below.
- **The background service worker** (`background/service-worker.js`) is the router. It owns no UI, makes no reasoning decisions, and (by design) makes zero network calls of its own — it's Chrome-API plumbing: injecting content scripts, capturing screenshots, managing the offscreen document, and relaying messages between the side panel and the offscreen document.
- **The offscreen document** (`offscreen.html` / `offscreen.js`) is where every on-device ML model actually runs — ONNX Runtime Web (NER, face detection), Tesseract.js (OCR confirmation), and WebLLM (on-device LLM reasoning). Content scripts and the service worker can't run WASM/WebGPU inference directly in all the contexts that need it, so this document exists purely to host that.
- **The side panel** (`popup/popup.html` + `popup/popup.js`, opened via Chrome's side panel API, not a detached popup window) is where the actual agent loop, all `agent/*.js` modules, and the UI live. This is the most code-dense part of the system by far (`popup.js` alone is ~3,000 lines) because it's where task planning, decision-making, privacy enforcement, and rendering all come together.

### Two content-script injection paths

`manifest.json`'s declarative `content_scripts` block auto-injects `lib/ort.min.js` + `content/piiDetector.js` into **every frame of every page**, unconditionally, the moment the extension loads — independent of whether the side panel has ever been opened. Separately, `background/service-worker.js`'s `ensureContentScriptInjected()` programmatically injects the *full* content-script list (`utils/logger.js`, `utils/geometry.js`, `utils/selectors.js`, `utils/i18nLabels.js`, `content/visibility.js`, `content/interactiveElements.js`, `content/iconCandidateDetector.js`, `content/textExtractor.js`, `content/piiDetector.js`, `content/idImageDetector.js`, `content/coordinateMapper.js`, `content/domExtractor.js`, `content/semanticDomBuilder.js`, `content/content.js`) on demand, whenever the side panel actually requests analysis or an action, using `chrome.scripting.executeScript({target:{tabId, allFrames:true}, files:[...]})`.

`content/piiDetector.js` is in both lists, so it can load twice into the same frame. Nothing in the codebase de-duplicates this beyond whatever idempotency the file's own top-level IIFE happens to provide — this is a real, unresolved quirk, not a documented-and-accepted design choice, and is worth checking before relying on any "runs exactly once per frame" assumption.

`content/content.js` itself does **not** use `chrome.runtime.onMessage` — it doesn't listen for extension messages at all. It exposes a `window.__BA` object (an action/extraction API — `runFullExtraction`, `click`, `type`, `select`, `navigate`, `highlightField`, etc.) that the service worker invokes directly via `chrome.scripting.executeScript({func: () => window.__BA.someMethod(...)})`. The only extension messaging content.js's world does is `content/piiDetector.js` calling `chrome.runtime.sendMessage` to request NER inference. Separately, `content.js` listens for native DOM events (`click`, `change`, `scroll`, `popstate`, `hashchange`) to build a metadata-only interaction log (action + element id + label — never a typed value), capped at 20 entries.

## One agent step, end to end

Each iteration of `popup.js`'s `runAgentLoop(task)` (a bounded `for` loop, `MAX_AGENT_STEPS`) goes through the same phases regardless of Privacy Dial mode, with the mode only changing *who* makes the actual next-action decision:

1. **Observe** — `analyzeCurrentPage()` triggers the service worker to inject content scripts (if needed), run `domExtractor.runExtraction()` in every frame, capture a screenshot (`chrome.tabs.captureVisibleTab`, retried with backoff against Chrome's undocumented rate limit), run face detection and NER (via the offscreen document), and merge multi-frame results (`mergeFrameExtractions` — same-origin subframe boxes are offset-corrected; a cross-origin subframe that reports sensitive content but can't self-locate causes its *entire* rectangle, as seen by the parent frame, to be redacted — coarse on purpose, so the failure mode is "too much blacked out," never "PII crossed the boundary").
2. **Local-vision short-circuit** — `utils/visualStateEngine.js` compares the current and previous screenshot frames (pure pixel statistics, no model) and can end the step early with `wait` (page still loading), `flag_ineffective_action` (the last click/type/select produced no visible change), or `constrain_to_dialog` (a modal/scrim is blocking the page) — all zero-network, zero-model decisions.
3. **Understand** — `agent/stateDiffEngine.js` diffs the current extraction against the previous one (URL change, added/removed elements, per-field `hasValue`/`enabled`/`visible` changes — metadata only, never values), and `agent/taskMemory.js` reconciles its short-term history against the live DOM (live DOM always wins over remembered state).
4. **Plan** — `agent/formAnalyzer.js` scores how much of the on-page form can be filled from the local `agent/privateDataStore.js` without asking the user anything.
5. **Zero-cloud fast path** — if the Privacy Dial isn't `cloud` and the execution mode is `complete` (not step-by-step HITL) and every empty field on the form resolves locally, the step fills those fields via `agent/fieldMatcher.js` + `agent/privateDataStore.js` directly, with no call to any reasoner at all.
6. **Decide the next action** — this is the one phase that actually branches on the Privacy Dial. See "Privacy Dial modes" below.
7. **Validate & execute** — `agent/consequentialActionDetector.js` checks whether the chosen target is a payment/delete/publish/submit/etc. action; if so, `authorizeAndExecuteConsequential()` (the 9-step human-authorization protocol) runs before anything happens. Otherwise the action executes directly via `window.__BA[actionName](...)` in the content script.
8. **Verify** — `agent/actionVerifier.js` classifies the outcome (`SUCCEEDED`, `NO_EFFECT`, `TARGET_DISAPPEARED`, `PAGE_CHANGED`, `TASK_COMPLETED`, `USER_INTERVENTION_REQUIRED`, `FAILED`) from the content-script response plus the state diff.
9. **Recover** — `agent/recoveryEngine.js` detects loops (repeated/oscillating actions with no effect) and diagnoses *why* a failed/no-op action happened (modal open, cookie banner, login required, validation error, page still loading, disabled/disappeared target), picking a bounded retry strategy or halting to ask the user after `MAX_CONSECUTIVE_FAILURES` (3).

## Privacy Dial modes — what actually happens today

`agent/privacyDial.js` stores one of four modes (`cloud`, `hybrid`, `local`, `debate`) in `chrome.storage.local`. The mode only changes step 6 above:

- **`cloud`** calls `agentBackend.decideNextAction(payload)` directly and unconditionally, every step — the single function in the entire extension that makes an outbound network request. This mode deliberately never attempts a local-first resolution: its purpose is maximum-capability comparison against the cloud reasoner, so it always uses it.
- **`hybrid`** calls `agent/decisionRouter.js`'s `route()` for every step (see below) — a 4-layer escalation (decision-tree → heuristic → local LLM → cloud) that only reaches `decideNextAction()` when none of the three local layers could confidently answer. If `decisionRouter` failed to load for some reason, this mode falls back to the same direct call `cloud` uses.
- **`local`** never calls `decideNextAction()` at all — `agentBackend.js` has a hard guard that throws if it's ever invoked while the dial is `local`, independent of what any caller does. Instead: `agentBackend.decideNextActionLocalOnly({extraction, formSummary})` (deterministic field-matching via `agent/fieldMatcher.js`) runs first; if it can't find a matchable empty field, `agentBackend.decideNextActionLocalLLM(...)` asks the on-device WebLLM model (Qwen2.5, run inside the offscreen document) as a fallback — still zero network requests, since the only message involved is an internal `chrome.runtime.sendMessage` to this extension's own offscreen document. If both decline, the step just waits and asks the user to act manually. This stays a separate inline implementation rather than calling `decisionRouter.js` (see below) because its total-failure fallback UX (retry the loop with a system message) is intentionally different from the router's.
- **`debate`** calls `agent/debateManager.js`'s `runDebate()`, which runs the local WebLLM path and the cloud `decideNextAction()` call *in parallel* via `Promise.allSettled`, scores both with `agent/confidenceScorer.js`, and resolves to whichever is more confident — showing the user both decisions and the gap between them when they disagree (see "Hybrid Debate" below). If `debateManager` isn't available for some reason, this mode falls back to the same direct call `cloud` uses.

`agent/decisionRouter.js` formalizes the 4-layer escalation (decision-tree → heuristic → local LLM → cloud) as a single, reusable, telemetry-producing class, and is loaded by `popup.html` and instantiated in `popup.js`. It backs `hybrid` mode's step above; `cloud` mode intentionally does not use it (see that mode's description). Its cumulative `getRoutingStats()` (how many steps this task resolved at each layer) renders live in the Privacy Receipt panel's "Local Decision Routing" subsection. `local` mode's inline tree-then-LLM fallback remains its own separate implementation rather than a `decisionRouter.js` call, for the fallback-UX reason given above — the duplication between the two is intentional, not an oversight.

## Hybrid Debate

When the dial is set to `debate`, every step runs both reasoners and compares them:

- **Agree** (same action, same target): use whichever side scored higher, no fuss shown to the user.
- **Disagree, confidence gap < 5%**: auto-resolve to the higher-confidence side.
- **Disagree, gap 5%–15%**: still auto-resolve, but the evidence panel shows both sides so the user can see the near-miss.
- **Disagree, gap ≥ 15%**: same resolution, but flagged strongly — the evidence panel recommends the user look before trusting it.
- **One side unavailable** (local model not vendored yet, or the cloud backend down): degrade to whichever side answered, clearly labeled `LOCAL_ONLY_DEGRADED` / `CLOUD_ONLY_DEGRADED`.
- **Both sides fail**: `runDebate()` throws rather than fabricating a decision.

Debate mode's confidence scoring (`agent/confidenceScorer.js`) is a geometric mean of whichever of these signals are actually available for a given decision: the reasoner's own self-reported confidence, the checksum strength of any PII the target touches, whether the page is HTTPS, a domain-reputation heuristic (or `agent/trustGate.js`'s real verdict when supplied), whether the target is a flagged consequential action, whether any touched PII is high-stakes, and simple task/label lexical overlap. A factor with no opinion (e.g. no PII on this field) is left out of the average rather than dragging the score toward zero.

Debate mode's cloud side makes the exact same `decideNextAction()` call `cloud` mode always makes and `hybrid` mode makes when its local layers decline — the payload and privacy profile of that specific call is identical everywhere it happens; debate is not a privacy-preserving mode on its own, it just makes the cloud call on every step rather than only when needed. Every consequential-action and sensitive-field safety gate applies identically no matter which side's decision "wins" a debate; debate changes what's shown, never what's allowed to happen autonomously.

## The perception stack

Everything below runs before a decision is made, feeding the DOM skeleton, sensitive-item list, and screenshot that reasoners (local or cloud) actually see:

- **DOM extraction** (`content/domExtractor.js`) orchestrates `interactiveElements.js` (finds every interactive element, including inside open shadow DOM, up to 12 levels deep), `textExtractor.js` (collects visible text runs with bounding boxes, via a `TreeWalker` per shadow scope), `visibility.js` (the single gatekeeper for "is this actually visible and unoccluded right now" — style checks plus an `elementFromPoint` occlusion test), `piiDetector.js` (see below), `idImageDetector.js` (keyword + aspect-ratio heuristics for photographed/scanned ID documents — no OCR, no model), and `iconCandidateDetector.js` (finds icon-only unlabeled buttons for the icon classifier).
- **PII detection** (`content/piiDetector.js`) is a regex + checksum layer (see `PRIVACY.md` for the full type table) plus an async NER pass that defers to the offscreen document's ONNX model.
- **Visual state** (`utils/visualStateEngine.js`) is classical pixel-differencing — no model, no network, a few milliseconds per frame — answering four questions the DOM can't reliably answer: is the page loading, is something blocking it (modal/scrim, detected with three independent tests including a flood-fill "brightest connected block" check that survives a full-height bright scrollbar), is a claimed-visible element actually painted, and did the last action change anything.
- **Icon classification** (`utils/iconClassifier.js` + `utils/iconModel.js`) is a real trained CNN — 6,862 parameters, int8-quantized, ~10KB, embedded directly in the JS file, no ONNX/WASM/network dependency — that labels icon-only buttons (menu/close/search/cart/etc.) or declines (`null`) below its 0.6 confidence threshold, on the principle that a wrong label actively misleads the reasoner while declining just leaves the status quo.
- **Face detection** (YuNet, ONNX, run in the offscreen document) and **NER** (a WordPiece-tokenized transformer, ONNX, same offscreen document) both feed redaction; NER's confidence threshold is 0.85 (a stale header comment in `offscreen.js` says 0.80 — the enforced code constant is 0.85).
- **ID-image OCR confirmation** (Tesseract.js, offscreen document) is confirmation-only: the heuristic `idImageRegions` from `idImageDetector.js` are redacted unconditionally regardless of whether OCR later confirms an ID-looking pattern in them; OCR just adds evidence, it never gates the redaction.

## Redaction and the privacy boundary

Two independent layers exist, one local-visual and one structural-data:

- **`content/redactor.js`** draws solid black rectangles onto a copy of the screenshot canvas for three region sources — DOM-detected PII (mapped from viewport CSS px to screenshot pixel space via `coordinateMapper.js`), faces (already in screenshot pixel space), and ID-image regions (double-padded). No blur or pixelation — just an opaque fill.
- **`agent/privacyBoundary.js`** is a second, independent, structural check on the *data* payload about to be sent to the cloud reasoner: `sanitizeOutboundPayload()` filters every object to an explicit allowlist of keys (elements, history entries, request fields, visual-state fields all have their own allowlist) and additionally regex-scans for adversarial patterns (credit card, PAN, Aadhaar, password-field key:value pairs) and prompt-injection attempts embedded in page text, replacing any match with a redaction placeholder. `assertSafeForTransmission()` then re-scans the fully-serialized payload against the same PII patterns (not the injection patterns) and hard-throws if anything unredacted is still present — this is what makes a payload's transmission abort rather than silently continue.

`agent/agentBackend.js` records every transmission attempt — success, or the adversarial-scan-blocked case — into a transmission summary the popup's Privacy Receipt panel renders live, including the exact sanitized payload text that crossed (or was blocked from crossing) the boundary. This is only exercised in the `cloud`/`hybrid`/`debate` paths; `local` mode makes no transmission and has nothing to report there.

## Cryptographic redaction proof

`utils/merkleProof.js` produces an independently-verifiable proof that a set of redacted screenshot regions really were part of one committed original image, without revealing any pixel content: it tiles the pre-redaction screenshot (64×64 by default), SHA-256-hashes every tile, builds a Merkle tree, and for each redacted region computes a standard Merkle inclusion proof plus an ECDSA P-256 signature over the whole manifest (a fresh, session-only keypair — this proves internal pipeline consistency, not a long-term PKI identity). `verifyRedactionProof()` takes only the proof object — no access to the original image or the extension — and checks the signature plus every tile's inclusion proof against the stated root. `tools/verify-redaction-proof.html` is a standalone page for a third party to run this check independently.

## Safety gates independent of Privacy Dial mode

These apply identically no matter which reasoner produced a decision:

- **`agent/consequentialActionDetector.js`** classifies whether a target is payment/delete/cancel/publish/booking/submit/approval/workflow-continuation, and the 9-step `authorizeAndExecuteConsequential()` protocol in `popup.js` (stop → re-observe → re-verify target → explain → ask → bind authorization to that exact action+target → re-verify after the wait → execute, consuming the authorization token immediately before executing → verify result) gates every one.
- **`agent/trustGate.js`** is a separate, deterministic, no-network phishing/look-alike-domain check run before autofilling private data — protects against the *page* being malicious, distinct from the consequential-action gate protecting against the *agent* doing something dangerous. It never blocks or allows unilaterally; it classifies (`allow`/`warn`/`block`) and the popup's HITL UI renders that for the user to decide.
- **`agent/fieldMatcher.js`** hard-excludes password fields from any matching logic — there is no code path that looks up or fills a password value automatically.
- **`agent/visualDomGrounder.js`** enforces that a visually-inferred click target must resolve to a real, validated DOM element (by exact containment or close proximity) before executing — raw screenshot coordinates are never clicked directly; if grounding fails, the action is rejected outright rather than executed blind.

## What's built but not yet wired in

`agent/decisionRouter.js` and `agent/complianceChecker.js` (described above and covered by their own passing tests) are now loaded by `popup.html` and actively called from `popup.js`'s loop. One module remains standalone:

- **`agent/contextManager.js`** — IndexedDB-backed cross-task checkpoint/resume. There is currently no task-list or resume-a-previous-task UI concept anywhere in `popup.js` for this to hook into; wiring it in means building that UI, not just adding a script tag, and that UI work hasn't been done.

See `IMPLEMENTATION.md` for the full status breakdown.
